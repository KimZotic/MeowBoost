export default function FAQ() {
  return <div className="text-white p-4">Frequently Asked Questions about MeowBoost services.</div>;
}
