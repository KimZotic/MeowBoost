export default function Services() {
  return <div className="text-white p-4">Our services include TikTok Followers, Instagram Likes, and more!</div>;
}
