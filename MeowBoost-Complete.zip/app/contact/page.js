export default function Contact() {
  return <div className="text-white p-4">Contact us at support@meowboost.com</div>;
}
