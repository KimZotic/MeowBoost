export default function About() {
  return <div className="text-white p-4">About MeowBoost: We provide social media boosting services.</div>;
}
