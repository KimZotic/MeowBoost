
export default function Header() {
  return (
    <header className="flex justify-between items-center p-4 bg-black text-white">
      <h1 className="text-2xl font-bold text-red-600">MeowBoost</h1>
      <nav className="space-x-4">
        <a href="/services">Services</a>
        <a href="/faq">FAQ</a>
        <a href="/about">About</a>
        <a href="/contact" className="bg-red-600 px-3 py-1 rounded text-white">Sign up</a>
      </nav>
    </header>
  );
}
