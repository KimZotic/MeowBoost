
export default function Footer() {
  return (
    <footer className="text-center p-4 mt-10 text-gray-400">
      &copy; 2025 MeowBoost. All rights reserved.
    </footer>
  );
}
