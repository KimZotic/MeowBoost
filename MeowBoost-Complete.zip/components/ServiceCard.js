
export default function ServiceCard({ icon, title, description }) {
  return (
    <div className="bg-zinc-900 p-4 rounded-lg shadow text-white">
      <div className="text-3xl mb-2">{icon}</div>
      <h3 className="text-xl font-bold mb-1">{title}</h3>
      <p className="text-sm text-gray-400">{description}</p>
    </div>
  );
}
